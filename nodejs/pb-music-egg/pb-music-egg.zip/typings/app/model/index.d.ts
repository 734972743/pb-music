// This file is created by egg-ts-helper@1.25.9
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAccess = require('../../../app/model/access');
import ExportAdmin = require('../../../app/model/admin');
import ExportAlbum = require('../../../app/model/album');
import ExportCarousel = require('../../../app/model/carousel');
import ExportFocus = require('../../../app/model/focus');
import ExportHistory = require('../../../app/model/history');
import ExportLabel = require('../../../app/model/label');
import ExportLanguage = require('../../../app/model/language');
import ExportLink = require('../../../app/model/link');
import ExportLyric = require('../../../app/model/lyric');
import ExportNavigation = require('../../../app/model/navigation');
import ExportPageContent = require('../../../app/model/page_content');
import ExportRole = require('../../../app/model/role');
import ExportRoleAccess = require('../../../app/model/role_access');
import ExportSinger = require('../../../app/model/singer');
import ExportSong = require('../../../app/model/song');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Access: ReturnType<typeof ExportAccess>;
    Admin: ReturnType<typeof ExportAdmin>;
    Album: ReturnType<typeof ExportAlbum>;
    Carousel: ReturnType<typeof ExportCarousel>;
    Focus: ReturnType<typeof ExportFocus>;
    History: ReturnType<typeof ExportHistory>;
    Label: ReturnType<typeof ExportLabel>;
    Language: ReturnType<typeof ExportLanguage>;
    Link: ReturnType<typeof ExportLink>;
    Lyric: ReturnType<typeof ExportLyric>;
    Navigation: ReturnType<typeof ExportNavigation>;
    PageContent: ReturnType<typeof ExportPageContent>;
    Role: ReturnType<typeof ExportRole>;
    RoleAccess: ReturnType<typeof ExportRoleAccess>;
    Singer: ReturnType<typeof ExportSinger>;
    Song: ReturnType<typeof ExportSong>;
    User: ReturnType<typeof ExportUser>;
  }
}
