// This file is created by egg-ts-helper@1.25.9
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportAdminAccess = require('../../../app/controller/admin/access');
import ExportAdminBase = require('../../../app/controller/admin/base');
import ExportAdminFocus = require('../../../app/controller/admin/focus');
import ExportAdminFocus1 = require('../../../app/controller/admin/focus1');
import ExportAdminLogin = require('../../../app/controller/admin/login');
import ExportAdminMain = require('../../../app/controller/admin/main');
import ExportAdminManager = require('../../../app/controller/admin/manager');
import ExportAdminRole = require('../../../app/controller/admin/role');
import ExportAdminUser = require('../../../app/controller/admin/user');
import ExportApiAlbum = require('../../../app/controller/api/album');
import ExportApiCarousel = require('../../../app/controller/api/carousel');
import ExportApiHistory = require('../../../app/controller/api/history');
import ExportApiLabel = require('../../../app/controller/api/label');
import ExportApiLanguage = require('../../../app/controller/api/language');
import ExportApiLink = require('../../../app/controller/api/link');
import ExportApiLyric = require('../../../app/controller/api/lyric');
import ExportApiNavigation = require('../../../app/controller/api/navigation');
import ExportApiPageContent = require('../../../app/controller/api/page_content');
import ExportApiSinger = require('../../../app/controller/api/singer');
import ExportApiSong = require('../../../app/controller/api/song');
import ExportApiUser = require('../../../app/controller/api/user');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    admin: {
      access: ExportAdminAccess;
      base: ExportAdminBase;
      focus: ExportAdminFocus;
      focus1: ExportAdminFocus1;
      login: ExportAdminLogin;
      main: ExportAdminMain;
      manager: ExportAdminManager;
      role: ExportAdminRole;
      user: ExportAdminUser;
    }
    api: {
      album: ExportApiAlbum;
      carousel: ExportApiCarousel;
      history: ExportApiHistory;
      label: ExportApiLabel;
      language: ExportApiLanguage;
      link: ExportApiLink;
      lyric: ExportApiLyric;
      navigation: ExportApiNavigation;
      pageContent: ExportApiPageContent;
      singer: ExportApiSinger;
      song: ExportApiSong;
      user: ExportApiUser;
    }
  }
}
