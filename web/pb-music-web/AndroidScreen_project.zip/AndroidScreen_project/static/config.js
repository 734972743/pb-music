// const BASE_URL = 'http://192.168.1.3:8089/index.php/new_tobacco'



const BASE_URL = 'http://121.41.120.198:9295/wisdom_campus/'

